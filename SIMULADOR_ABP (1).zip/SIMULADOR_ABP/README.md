# simulador-de-prestamo
Este es un trabajo de simulador de prestamos
## Este  es un SIMULADOR DE PRESTAMOS
---
## SCREENSHOT
---
![CAPTURA DE PANTALLA](http://imgfz.com/i/Kn0Y1x6.jpeg)
---
## Preview: <https://simulador-de-prestamo.netlify.app/>