function agregarInfo() {
    // Obtiene los valores de los inputs
    let nombre = document.getElementById("nombre").value;
    let telefono = document.getElementById("telefono").value;
    let direccion = document.getElementById("direccion").value;

    // Deshabilita los campos para evitar ediciones accidentales
    document.getElementById("nombre").disabled = true;
    document.getElementById("telefono").disabled = true;
    document.getElementById("direccion").disabled = true;

    // Muestra la información en el contenedor
    document.getElementById("userInfoDisplay").innerHTML = `
        <strong>Nombre:</strong> ${nombre}<br>
        <strong>Teléfono:</strong> ${telefono}<br>
        <strong>Dirección:</strong> ${direccion}`;
}

function editarInfo() {
    // Habilita los campos para permitir la edición
    document.getElementById("nombre").disabled = false;
    document.getElementById("telefono").disabled = false;
    document.getElementById("direccion").disabled = false;

    // Pone el foco en el primer campo para facilitar la edición
    document.getElementById("nombre").focus();
}

function gen_table() {
    document.getElementById("tab").innerHTML = "";
    let capital = Number(document.getElementById("capital").value);
    let cuotas = Number(document.getElementById("couta").value);
    let interes = Number(document.getElementById("interes").value);

    if (capital > 0 && cuotas > 0 && interes >= 0) {
        let totalInterest = 0;
        let totalPayment = 0;

        for (let i = 1; i <= cuotas; i++) {
            let principal = capital / cuotas;
            let interest = ((capital * interes) / 100) / cuotas;
            let payment = principal + interest;

            document.getElementById("tab").innerHTML += `<tr>
                <td>${i}</td>
                <td>${principal.toFixed(2)}</td>
                <td>${interest.toFixed(2)}</td>
                <td>${payment.toFixed(2)}</td>
            </tr>`;

            totalInterest += interest;
            totalPayment += payment;
        }

        document.getElementById("t1").innerHTML = capital.toFixed(2);
        document.getElementById("t2").innerHTML = totalInterest.toFixed(2);
        document.getElementById("t3").innerHTML = totalPayment.toFixed(2);
    } else {
        alert("Por favor, asegúrate de ingresar valores válidos para capital, cuotas e interés.");
    }
}